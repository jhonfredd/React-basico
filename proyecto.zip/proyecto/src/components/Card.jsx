import React from 'react'
import PropType from 'prop-types'
import  "./Card.css"

const Card = ({lang, img, fcolor ,scolor}) => {

  return (
    <div className="card" style={{
      background:  `linear-gradient(to left,${fcolor}, ${scolor}`,
    }}>
        <img src={img} alt="lang" />
        <h3> {lang} </h3>
    </div>
  )
}

Card.propTypes = {
  lang:PropType.string,
  img:PropType.string,
  fcolor:PropType.string,
  scolor:PropType.string,
}


export default Card
