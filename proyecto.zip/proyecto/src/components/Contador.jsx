import { useState } from 'react'

const Contador = (props) => {
  const [contador, setContador] =  useState(props.inicial);
  
  const aumentar = () => {
    setContador(valor => valor + props.factor);
  }
  
  const disminuir = () => {
    setContador(valor => valor - props.factor);
  }

  return (
    <div>
      <h1>Contador : {contador}</h1>
      <button onClick={aumentar} >Aumentar</button>
      <button onClick={disminuir} >Disminuir</button>
    </div>
  )
}

export default Contador
