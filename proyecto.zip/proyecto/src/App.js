import Cards from './components/Cards';

const App = () => {
  // return <Contador inicial={5} factor={2} />;
  return <Cards/>
}

export default App;
