import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "../pages/Home";
import Headers from "../components/Headers";
import About from "../pages/About";
import NotFound from "../pages/NotFound";

const AppRouter = ({isDarkTheme, setIsDarkTheme}) => {
  return (
    <Router>
      <Headers isDarkTheme={isDarkTheme} setIsDarkTheme={setIsDarkTheme} />
      <Routes>
        <Route exact path="/" element={<Home />} />
        <Route exact path="/about" element={<About />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
};

export default AppRouter;
