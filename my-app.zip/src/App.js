import { useState } from "react";
import AppRouter from "./routers/AppRouter";
import { UserContext } from "./contexts/UserContext";

const App = () => {
  const [user, setUser] = useState(null);
  const [isDarkTheme, setIsDarkTheme] = useState(true);

  return (
    <div className={isDarkTheme ? "App dark-theme" : "App light-theme"}>
      <UserContext.Provider value={{ user, setUser }}>
        <AppRouter isDarkTheme={isDarkTheme} setIsDarkTheme={setIsDarkTheme} />
      </UserContext.Provider>
    </div>
  );
};

export default App;
