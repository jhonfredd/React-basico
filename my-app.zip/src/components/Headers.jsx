import React from "react";
import { Link } from "react-router-dom";
import "../App.css";

const Headers = ({ isDarkTheme, setIsDarkTheme }) => {
  const toggleTheme = () => {
    setIsDarkTheme(!isDarkTheme);

    document.body.classList.toggle("dark-theme", !isDarkTheme);
    document.body.classList.toggle("light-theme", isDarkTheme);

    const uno = document.getElementById("uno");

    if (isDarkTheme) {
      uno.classList.add("fa-sun");
    } else {
      uno.classList.add("fa-moon");
    }
  };

  return (
    <nav
      className="navbar bg-dark border-bottom border-body"
      data-bs-theme="dark"
    >
      <div className="container-fluid">
        <h2 className="navbar-brand">Context APP</h2>
        <div className="d-flex align-items-center">
          <button
            style={{ top: "5px", position: "static" }}
            className="btn btn-primary toggle-button mx-3"
            onClick={toggleTheme}
          >
            <i id="uno" className="fas fa-moon"></i> Cambiar Tema
          </button>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
        </div>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav  me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link className="nav-link active" aria-current="page" to="/">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link active" aria-current="page" to="/about">
                About
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Headers;
